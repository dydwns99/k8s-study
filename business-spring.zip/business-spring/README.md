# 📖 K8S - study 실습용 프로젝트

---
## ✏️ 설명


- 본 프로젝트는 쿠버네티스 스터디 실습에 사용하기 위한 프로젝트 입니다.

- spring boot 를 사용하여 '회원등록' 과 '회원조회' 을 할 수 있는 웹페이지를 간단하게 구현하였습니다.

---
## 🐳 도커 컨테이너로 실행하는 방법

1. zip 파일을 풀어서 프로젝트를 열기 

   1. application.properties 변경
   
      /src/main/resources/application.properties 파일에서 **spring.datasource.url의 값을 H2 연결화면에서 JDBC URL** 과 일치 시킨다.]

   2. 콘솔로 이동하여 프로젝트 빌드 하여  .jar 파일을 새로 생성한다.

      `./gradlew build`


2. H2 데이터베이스 실행방법 [**추후 dockercompose 로 실행할 예정**]
   1. H2 database 1.4.199 버전 설치 
   
      https://h2database.com/h2-2019-03-13.zip 
   2. 실행권한 변경     
     
      `chmod 755 h2.sh`
   
   3. H2 실행    
     
      `./h2.sh -webAllowOthers`

   4. URL 주소 변경

      `자신의 IP주소`:8082/login.do~

   5. JDBC URL 변경
      
      처음엔 변경 안한 상태로 연결 후 다시 나와 연결할 때 변경
   
      `jdbc:h2:tcp://자신의 IP주소/~/test`


3. dockerfile 빌드

   `docker build --build-arg JAR_FILE=build/libs/business-spring-0.0.1-SNAPSHOT.jar -t myorg/myapp --platform linux/amd64 .`


4. dockerfile 실행

   `docker run -p 8080:8080 myorg/myapp`

---
## 🛠️ 실행 환경 & 적용기술 

- Mac OS

- Spring Boot

- H2 데이터베이스

- JPA