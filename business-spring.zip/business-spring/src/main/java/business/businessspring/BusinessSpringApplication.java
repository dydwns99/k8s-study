package business.businessspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusinessSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusinessSpringApplication.class, args);
	}

}
