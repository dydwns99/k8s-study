package business.businessspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusinessSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
